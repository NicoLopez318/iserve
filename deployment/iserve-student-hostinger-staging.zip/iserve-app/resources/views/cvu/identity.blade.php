<label>Full name<input name="name" maxlength="120" value="{{ old('name',$u->name) }}" required></label>
<label>Student ID<input name="student_id" maxlength="40" value="{{ old('student_id',$u->student_id) }}" required></label>
<label>Contact<input name="contact" maxlength="40" value="{{ old('contact',$u->phone) }}" required></label>
<label>Course<select name="course" required><option value="">Select course</option>@foreach($courses->push($u->course)->filter()->unique() as $course)<option @selected(old('course',$u->course)===$course)>{{ $course }}</option>@endforeach</select></label>
<label>Year<select name="year_level" required><option value="">Select year</option>@foreach(App\Http\Controllers\CvuFlowController::YEARS as $year)<option @selected(old('year_level',$u->year_level)===$year)>{{ $year }}</option>@endforeach</select></label>

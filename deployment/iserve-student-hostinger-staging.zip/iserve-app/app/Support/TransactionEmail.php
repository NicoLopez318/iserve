<?php

namespace App\Support;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Throwable;

final class TransactionEmail
{
    public static function sendAfterCommit(User $recipient, string $subject, string $body, array $context): void
    {
        if (!($recipient->preferences['email'] ?? true)) {
            return;
        }

        DB::afterCommit(function () use ($recipient, $subject, $body, $context) {
            try {
                Mail::raw($body, fn ($message) => $message->to($recipient->email)->subject($subject));
            } catch (Throwable $error) {
                Log::warning('Transaction email delivery failed', [
                    ...$context,
                    'mailer' => config('mail.default'),
                    'exception_type' => $error::class,
                    'exception_code' => $error->getCode(),
                ]);
            }
        });
    }

    public static function receipt(\App\Models\ServiceRequest $request, bool $resubmitted = false): void
    {
        if ($request->office() !== 'cvu_head') {
            return;
        }

        $action = $resubmitted ? 'resubmitted' : 'received';
        $requestUrl = rtrim(config('app.url'), '/').'/requests/'.$request->id;
        self::sendAfterCommit(
            $request->user,
            'iServe request '.$action.': '.$request->ticket,
            "Your request {$request->ticket} was {$action} and is pending review.\n\nView your request: {$requestUrl}",
            ['request_id' => $request->id],
        );
    }
}

<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Report extends Model {protected $guarded=['id'];protected function casts():array{return ['snapshot'=>'array'];}public function user(){return $this->belongsTo(User::class);}}

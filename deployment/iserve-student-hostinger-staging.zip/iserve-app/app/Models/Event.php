<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Event extends Model {protected $guarded=['id']; protected function casts():array{return ['starts_at'=>'datetime','ends_at'=>'datetime','metadata'=>'array'];} public function attendances(){return $this->hasMany(Attendance::class);} }
